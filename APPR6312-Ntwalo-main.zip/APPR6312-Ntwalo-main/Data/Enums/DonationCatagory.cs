﻿namespace Ntwalo_APPR6312.Data.Enums
{
    public enum DonationCatagory
    {
        Clothes,
        NonPerishableFood
    }
}
